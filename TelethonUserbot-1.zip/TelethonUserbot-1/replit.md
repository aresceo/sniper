# Overview

This is a Telegram Username Sniper Bot built with Telethon that monitors username availability and automatically creates channels when usernames become available. The system manages multiple Telegram accounts, distributes username monitoring tasks across them, and creates channels with sniped usernames using a predefined template.

# User Preferences

Preferred communication style: Simple, everyday language.
Interface language: Italian - All bot messages, commands responses, and notifications are in Italian.

# System Architecture

## Core Application Structure

The application follows a modular architecture with clear separation of concerns:

- **Main Entry Point** (`main.py`, `userbot.py`): Coordinates all components and handles user commands
- **Account Management** (`account_manager.py`): Manages multiple Telegram sessions and authentication
- **Username Monitoring** (`username_monitor.py`): Distributes and monitors username availability across accounts
- **Channel Creation** (`channel_creator.py`): Creates channels with sniped usernames
- **Database Layer** (`database.py`): SQLite-based persistence for accounts, usernames, and configuration
- **Configuration** (`config.py`): Centralized settings and environment variables

## Authentication & Session Management

The system uses Telethon's session-based authentication:
- Main userbot session for receiving commands
- Multiple account sessions stored in the `sessions/` directory
- Two-factor authentication support with phone verification codes
- Session persistence using SQLite database

## Monitoring Architecture

Username monitoring uses a distributed approach:
- Usernames are split evenly across available accounts
- Each account checks assigned usernames sequentially with configurable delays
- Accounts work in pairs with rotation delays to avoid rate limiting
- Flood control and error handling for API rate limits

## Data Storage

JSON-based file system for persistent data storage across restarts:
- **data/accounts.json**: Phone numbers, session paths, and active status
- **data/usernames.json**: Monitored usernames with timestamps and status
- **data/config.json**: Key-value configuration storage
- **data/sniped_history.json**: History of successfully sniped usernames

## Command Interface

Event-driven command system using Telethon's event handlers:
- `.new` - Add new account with phone verification
- `.code` - Complete phone verification
- `.voip` - List connected accounts
- `.addusername`/`.delusername` - Manage monitored usernames
- `.lista` - Show monitored usernames
- `.setime` - Configure check intervals
- `.coppia` - Configure pair rotation delays

## Channel Creation Logic

When an available username is detected:
1. Creates a new Telegram channel
2. Sets the sniped username
3. Applies predefined title template: "sniped by @stabbato"
4. Posts configured message: ".︻芫═─── @stabbato"
5. Automatically removes username from monitoring list after successful snipe
6. Adds sniped username to history database with timestamp, channel link, and account used

# External Dependencies

## Third-Party Libraries
- **Telethon**: Telegram MTProto API client for Python
- **SQLite3**: Built-in Python database (no external dependency)
- **AsyncIO**: Built-in Python async framework

## Telegram API Integration
- Requires `TELEGRAM_API_ID` and `TELEGRAM_API_HASH` environment variables
- Uses Telegram Bot API for session management and channel operations
- Integrates with Telegram's username system and channel creation APIs

## File System Dependencies
- Session files stored in `sessions/` directory
- JSON data files stored in `data/` directory (accounts, usernames, config, sniped history)
- Log file (`sniper.log`) for debugging and monitoring

## Configuration Requirements
- Environment variables for Telegram API credentials
- Configurable rate limiting parameters
- Customizable channel templates and messages